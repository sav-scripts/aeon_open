/**
 * Created by sav on 2015/8/18.
 */
var send_data = {
    "user_name": "John",
    "phone": "0955666444",
    "address_county": "台北市",
    "address_zone": "士林區",
    "address_detail": "xx路xx巷xx號"

};

var recive_data = {
    "res": "ok"
};